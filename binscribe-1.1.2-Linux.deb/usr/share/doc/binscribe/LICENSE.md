# MIT License

Copyright (c) 2025 Dalibor Klobučarić

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the “Software”), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---

## Third-Party Notices

This project’s **source code** is licensed under the MIT License above.

Binary distributions of BinScribe may **bundle Qt libraries**, which are licensed
under **LGPL v3** (and may include additional third-party notices from Qt).

To comply with LGPL:
- End users may replace the bundled Qt DLLs with their own builds.
- Include the full text of **LGPL-3.0** in your distribution (e.g. at `licenses/LGPL-3.0.txt`).
- Include Qt’s third-party notices (e.g. `licenses/Qt-Third-Party-Notices.txt`).

For more information on Qt licensing, see: https://www.qt.io/terms-conditions/
